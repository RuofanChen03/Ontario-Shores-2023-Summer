/*
Abandoned scripts:



-- For getting columns
SELECT
	C.object_id,
	C.name AS ColName,
	T.name AS TblName,
	C.collation_name,
	C.max_length

from sys.all_columns AS C

INNER JOIN sys.tables AS T

	ON C.object_id	= T.object_id

WHERE C.name like '%date%'			--'ProcedureID'
ORDER BY TblName;
--ORDER BY ColName;



-- For combining comments using cursors
DROP TABLE IF EXISTS #tmp_micSpecCommentsCombined;

CREATE TABLE #tmp_micSpecCommentsCombined (
    AccountNumber		VARCHAR(18),
	SpecimenID			VARCHAR(MAX),
	Comments			VARCHAR(MAX),
	CollectionDateTime	DATETIME,
	ReceivedDateTime	DATETIME
);

DECLARE		@accnum		VARCHAR(18),
			@specid		VARCHAR(MAX), 
			@comments	VARCHAR(MAX),
			@colltime	DATETIME,
			@recvtime	DATETIME;

IF CURSOR_STATUS('global','cur') >= -1
	BEGIN
		DEALLOCATE cur;
	END;

DECLARE cur SCROLL CURSOR FOR 
	SELECT DISTINCT
		SpecimenID 
	FROM #tmp_micSpecComments;

OPEN cur;
FETCH FIRST FROM cur INTO @specid;

WHILE @@FETCH_STATUS = 0  
    BEGIN
		Select	@comments	=	COALESCE(@comments + '|' + TextLine, TextLine), 
				@accnum		=	OrderedMS.AccountNumber,
				@colltime	=	OrderedMS.CollectionDateTime,
				@recvtime	=	OrderedMS.ReceivedDateTime
		FROM (
			SELECT * 
			FROM #tmp_micSpecComments
			ORDER BY ResultSeqID, TextID OFFSET 0 ROWS
			) AS OrderedMS
		WHERE 
			OrderedMS.SpecimenID = @specid;

		INSERT INTO #tmp_micSpecCommentsCombined 
					(AccountNumber,	SpecimenID,	Comments,	CollectionDateTime, ReceivedDateTime)
			VALUES	(@accnum,		@specid,	@comments,	@colltime, @recvtime);

		FETCH NEXT FROM cur INTO @specid;
		SET @comments = '';
    END;

CLOSE cur;
DEALLOCATE cur;

Select *
FROM #tmp_micSpecCommentsCombined	AS MS_COM;



--Getting Organism Names using distinct
SELECT DISTINCT

	AccountNumber,
	VisitID,
	PatientID,
	SpecimenID,
	OrganismName

FROM #tmp_micSpec

WHERE OrganismName IS NOT NULL

ORDER BY AccountNumber, SpecimenID, OrganismName;



--Showing multiple procedureID leading to different Organisms (especially Comment)
SELECT 
	MSO.SpecimenID,
	MSO.ProcedureID,
	MSO.OrganismName,
	DMP.Name
FROM dbo.MicSpecimenOrganisms	AS MSO
LEFT JOIN dbo.DMicProcs AS DMP		--- changing entries? fields from it?
		ON	MSO.ProcedureID =	DMP.ProcedureID
where SpecimenID = '2717'
;
*/



-------For getting all AccountNumbers and other info-------------------------------------------------

DROP TABLE IF EXISTS #tmp_micSpecMaster;

SELECT

	RAM.AccountNumber,
	RAM.VisitID,
	RAM.PatientID,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime
	
INTO #tmp_micSpecMaster

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID

WHERE

	RAM.Facility_MisFacID IN ('WHA', 'OSCMHS')
--AND	MS.Status = 'COMP'													-- For completed orders only
;


-----------Getting Comment & Overall (for COVID Test) Sections----------------------------------


DROP TABLE IF EXISTS #tmp_micSpecComments;

SELECT

	RAM.AccountNumber,
	MS.SpecimenID,
	MSRT.TextLine,
	MSRT.ResultSeqID, 
	MSRT.TextSeqID, 
	MSRT.TextID,
	MS.CollectionDateTime

INTO #tmp_micSpecComments

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN dbo.MicSpecimenProcedures AS DLT
		ON	DLT.SourceID	=	'CEL'
		AND	MS.SpecimenID	=	DLT.SpecimenID

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID

	LEFT JOIN dbo.MicSpecimenResultsText AS MSRT
		ON	MS.SpecimenID	=	MSRT.SpecimenID 
		AND	DLT.ProcedureID	=	MSRT.ProcedureID

WHERE

	MSRT.SourceID	IS NOT NULL
AND	DLT.ProcedureID	in ('400.30070', '400.30500')						-- For only the comment & overall section
AND	RAM.Facility_MisFacID IN ('WHA', 'OSCMHS')
--AND MS.Status = 'COMP'													-- For completed orders only
;


--For getting the most recent comments only, using AccountNumber & SpecimenID
DROP TABLE IF EXISTS #tmp_micSpecCommentsRecent;

SELECT

	MS.AccountNumber,
	MS.SpecimenID,
	MS.ResultSeqID,
	MS.TextSeqID,
	MS.TextID,
	MS.TextLine,
	MS.CollectionDateTime

INTO #tmp_micSpecCommentsRecent

FROM #tmp_micSpecComments AS MS

	INNER JOIN (

		SELECT

			MSTEMP.AccountNumber,
			MSTEMP.SpecimenID,
			MAX(MSTEMP.ResultSeqID) AS MAXRESSEQID

		FROM #tmp_micSpecComments AS MSTEMP

		GROUP BY AccountNumber, SpecimenID) AS MAXRESSEQ

		ON	MS.ResultSeqID		=	MAXRESSEQ.MAXRESSEQID
		AND MS.AccountNumber	=	MAXRESSEQ.AccountNumber
		AND MS.SpecimenID		=	MAXRESSEQ.SpecimenID
;


-----------Getting Organisms' Names----------------------------------


DROP TABLE IF EXISTS #tmp_micSpecOrganisms;

SELECT
	
	RAM.AccountNumber,
	MS.SpecimenID,
	MSO.OrganismName,
	MSO.ResultSeqID,
	MS.CollectionDateTime

INTO #tmp_micSpecOrganisms

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID
				
	LEFT JOIN dbo.MicSpecimenOrganisms AS MSO
		ON	MS.SpecimenID	=	MSO.SpecimenID
		AND	RAM.VisitID		=	MSO.VisitID

WHERE 

	MSO.OrganismName IS NOT NULL
AND	RAM.Facility_MisFacID IN ('WHA', 'OSCMHS')
--AND MS.Status = 'COMP'													-- For completed orders only
;


--For getting the most recent organisms only, using AccountNumber & SpecimenID
DROP TABLE IF EXISTS #tmp_micSpecOrganismsRecent;

SELECT
	
	MS.AccountNumber,
	MS.SpecimenID,
	MS.OrganismName,
	MS.ResultSeqID,
	MS.CollectionDateTime

INTO #tmp_micSpecOrganismsRecent

FROM	#tmp_micSpecOrganisms AS MS
	
	INNER JOIN (

		SELECT

			MSTEMP.AccountNumber,
			MSTEMP.SpecimenID,
			MAX(MSTEMP.ResultSeqID) AS MAXRESSEQID

		FROM #tmp_micSpecOrganisms AS MSTEMP

		GROUP BY AccountNumber, SpecimenID) AS MAXRESSEQ

		ON	MS.ResultSeqID		=	MAXRESSEQ.MAXRESSEQID
		AND MS.AccountNumber	=	MAXRESSEQ.AccountNumber
		AND MS.SpecimenID		=	MAXRESSEQ.SpecimenID
;