USE testdb

DROP TABLE IF EXISTS #tmp_micSpec;

SELECT
	
	RAM.AccountNumber, 
	DMP.Name,   
	MSRT.TextLine,
	MSRT.ResultSeqID, 
	MSRT.TextSeqID, 
	MSRT.TextID,
	MSO.OrganismName,
	MS.SpecimenID,
	MS.CollectionDateTime
	
INTO #tmp_micSpec

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN MicSpecimenProcedures AS DLT
		ON	DLT.SourceID	=	'CEL'
		AND	MS.SpecimenID	=	DLT.SpecimenID

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID

	LEFT JOIN dbo.MicSpecimenResultsText AS MSRT
		ON	MS.SpecimenID	=	MSRT.SpecimenID 
		AND	DLT.ProcedureID	=	MSRT.ProcedureID
				
	LEFT JOIN dbo.MicSpecimenOrganisms AS MSO
		ON	MS.SpecimenID	=	MSO.SpecimenID
		AND DLT.ProcedureID	=	MSO.ProcedureID
		AND	RAM.VisitID		=	MSO.VisitID

	LEFT JOIN dbo.DMicProcs AS DMP
		ON	MSRT.ProcedureID =	DMP.ProcedureID

WHERE
	MSRT.SourceID	is not NULL;


/* Getting "Comment" Section*/

DROP TABLE IF EXISTS #tmp_micSpecComments;

SELECT DISTINCT

	MS.AccountNumber,
	MS.TextLine,
	MS.ResultSeqID,
	MS.TextSeqID,
	MS.TextID,
	MS.SpecimenID,
	MS.CollectionDateTime

INTO #tmp_micSpecComments

FROM #tmp_micSpec AS MS

--For getting most recent only, using AccountNumber & SpecimenID
INNER JOIN (

	SELECT

		MSTEMP.AccountNumber,
		MSTEMP.SpecimenID,
		MAX(MSTEMP.ResultSeqID) AS MAXRESSEQID

	FROM #tmp_micSpec AS MSTEMP

	GROUP BY AccountNumber, SpecimenID) AS MAXRESSEQ

	ON	MS.ResultSeqID		=	MAXRESSEQ.MAXRESSEQID
	AND MS.AccountNumber	=	MAXRESSEQ.AccountNumber
	AND MS.SpecimenID		=	MAXRESSEQ.SpecimenID
;

SELECT 
	*
FROM #tmp_micSpecComments AS MS
ORDER BY MS.AccountNumber, MS.SpecimenID, MS.TextID;