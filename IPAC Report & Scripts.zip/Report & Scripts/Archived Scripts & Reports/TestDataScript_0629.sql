/*
SELECT
	C.object_id,
	C.name AS ColName,
	T.name AS TblName,
	C.collation_name,
	C.max_length

from sys.all_columns AS C

INNER JOIN sys.tables AS T

	ON C.object_id	= T.object_id

WHERE C.name like '%date%'			--'ProcedureID'
ORDER BY TblName;
--ORDER BY ColName;
*/



USE testdb

DROP TABLE IF EXISTS #tmp_micSpec;

SELECT
	
	RAM.AccountNumber, 
	DMP.Name,   
	MSRT.TextLine,
	MSRT.ResultSeqID, 
	MSRT.TextSeqID, 
	MSRT.TextID,
	MSO.OrganismName,
	MS.SpecimenID,
	MS.CollectionDateTime
	
INTO #tmp_micSpec

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN MicSpecimenProcedures AS DLT
		ON	DLT.SourceID	=	'CEL'
		AND	MS.SpecimenID	=	DLT.SpecimenID

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID

	LEFT JOIN dbo.MicSpecimenResultsText AS MSRT
		ON	MS.SpecimenID	=	MSRT.SpecimenID 
		AND	DLT.ProcedureID	=	MSRT.ProcedureID
				
	LEFT JOIN dbo.MicSpecimenOrganisms AS MSO
		ON	MS.SpecimenID	=	MSO.SpecimenID
		AND DLT.ProcedureID	=	MSO.ProcedureID
		AND	RAM.VisitID		=	MSO.VisitID

	LEFT JOIN dbo.DMicProcs AS DMP
		ON	MSRT.ProcedureID =	DMP.ProcedureID

WHERE
	MSRT.SourceID	is not NULL;


/* Getting "Comment" Section*/

DROP TABLE IF EXISTS #tmp_micSpecComments;

SELECT DISTINCT

	MS.AccountNumber,
	MS.TextLine,
	MS.ResultSeqID,
	MS.TextSeqID,
	MS.TextID,
	MS.SpecimenID,
	MS.CollectionDateTime

INTO #tmp_micSpecComments

FROM #tmp_micSpec AS MS

--For getting most recent only, using AccountNumber & SpecimenID
INNER JOIN (

	SELECT

		MSTEMP.AccountNumber,
		MSTEMP.SpecimenID,
		MAX(MSTEMP.ResultSeqID) AS MAXRESSEQID

	FROM #tmp_micSpec AS MSTEMP

	GROUP BY AccountNumber, SpecimenID) AS MAXRESSEQ

	ON	MS.ResultSeqID		=	MAXRESSEQ.MAXRESSEQID
	AND MS.AccountNumber	=	MAXRESSEQ.AccountNumber
	AND MS.SpecimenID		=	MAXRESSEQ.SpecimenID
;

SELECT 
	*
FROM #tmp_micSpecComments AS MS
ORDER BY MS.AccountNumber, MS.SpecimenID, MS.TextID;


/* Collecting Comments Together */
DROP TABLE IF EXISTS #tmp_micSpecCommentsCombined;

CREATE TABLE #tmp_micSpecCommentsCombined (
    AccountNumber		VARCHAR(18),
	SpecimenID			VARCHAR(MAX),
	Comments			VARCHAR(MAX),
	CollectionDateTime	DATETIME
);

DECLARE		@accnum		VARCHAR(18),
			@specid		VARCHAR(MAX), 
			@comments	VARCHAR(MAX),
			@colltime	DATETIME;

IF CURSOR_STATUS('global','cur') >= -1
	BEGIN
		DEALLOCATE cur;
	END;

DECLARE cur SCROLL CURSOR FOR 
	SELECT DISTINCT
		SpecimenID 
	FROM #tmp_micSpecComments;

OPEN cur;
FETCH FIRST FROM cur INTO @specid;

WHILE @@FETCH_STATUS = 0  
    BEGIN
		Select	@comments	=	COALESCE(@comments + ' | ' + TextLine, TextLine), 
				@accnum		=	OrderedMS.AccountNumber,
				@colltime	=	OrderedMS.CollectionDateTime
		FROM (
			SELECT * 
			FROM #tmp_micSpecComments
			ORDER BY ResultSeqID, TextID OFFSET 0 ROWS
			) AS OrderedMS
		WHERE 
			OrderedMS.SpecimenID = @specid;

		INSERT INTO #tmp_micSpecCommentsCombined 
					(AccountNumber,	SpecimenID,	Comments,	CollectionDateTime)
			VALUES	(@accnum,		@specid,	@comments,	@colltime);

		FETCH NEXT FROM cur INTO @specid;
		SET @comments = '';
    END;

CLOSE cur;
DEALLOCATE cur;

Select *
FROM #tmp_micSpecCommentsCombined	AS MS_COM
ORDER BY AccountNumber;