DROP TABLE IF EXISTS #tmp_micSpecOrganisms;


SELECT
	
	RAM.AccountNumber,
	RAM.VisitID,
	RAM.PatientID,
	MSO.OrganismName,
	MSO.ResultSeqID,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime

INTO #tmp_micSpecOrganisms

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN testfocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID
				
	LEFT JOIN dbo.MicSpecimenOrganisms AS MSO
		ON	MS.SpecimenID	=	MSO.SpecimenID
		AND	RAM.VisitID		=	MSO.VisitID

WHERE
	MSO.OrganismName IS NOT NULL
AND	RAM.Facility_MisFacID IN ('WHA', 'OSHMHS')
AND	MS.CollectionDateTime >= DATEADD(HOUR, -1, GETDATE());



SELECT
	
	MS.AccountNumber,
	MS.VisitID,
	MS.PatientID,
	MS.OrganismName,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime

FROM	#tmp_micSpecOrganisms AS MS
	
	INNER JOIN (
		SELECT

			MSTEMP.AccountNumber,
			MSTEMP.SpecimenID,
			MAX(MSTEMP.ResultSeqID) AS MAXRESSEQID

		FROM #tmp_micSpecOrganisms AS MSTEMP

		GROUP BY AccountNumber, SpecimenID) AS MAXRESSEQ

		ON	MS.ResultSeqID		=	MAXRESSEQ.MAXRESSEQID
		AND MS.AccountNumber	=	MAXRESSEQ.AccountNumber
		AND MS.SpecimenID		=	MAXRESSEQ.SpecimenID
;