/*
Tables:
	DIM_Specimen: 
		VisitID,
		SpecimenID,
		CollectionDateTime,
		ReceivedDateTime

		Status,										(of records; COMP/RES/UNV selected)			*NEW*
		RegistrationStatus							(of patients)								*NEW*

	DIM_Procedure:
		SpecimenID,
		ProcedureID,
		ProcedureName

	DIM_Comment_Overall:
		SpecimenID
		LinkProcedureID
		IsOverall
		IsComment
		Complete
		ResultText

		ProcedureID							(of patients)								*NEW*
	DIM_Organisms:
		SpecimenID,
		OrganismName

*/


DROP TABLE IF EXISTS #tmp_DIM_Specimen;


SELECT
	
	ISNULL(ISNULL(PV2.ConvertedAcct_AcuteVisitID, PV1.ConvertedAcct_AcuteVisitID), PV1.VisitID)	AS VisitID,
	MS.Status,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime,
	COALESCE(PV2.RegistrationStatus, PV1.RegistrationStatus)									AS RegistrationStatus,
	CASE
		WHEN (DATEDIFF(DAY, MS.CollectionDateTime, GETDATE()) <= 7)
			THEN 1
		ELSE 0
	END																							AS Recent7Days

--INTO #tmp_DIM_Specimen

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN DW_OSC.Patient.PatientVisit AS PV1
		ON	MS.VisitID				=	PV1.VisitID

	LEFT JOIN DW_OSC.Patient.PatientVisit AS PV2
		ON	MS.VisitID				=	PV2.ConvertedAcct_AcuteVisitID

WHERE

	MS.Status											IN ('COMP', 'RES', 'UNV')
AND	ISNULL(PV2.ConvertedAcct_AcuteVisitID, PV1.VisitID)	IS NOT NULL
;


DROP TABLE IF EXISTS #tmp_DIM_Procedure;

SELECT
	
	MS.SpecimenID,
	DLT.ProcedureID,
	DMP.Name							AS	ProcedureName,
	DLT.Complete
	
--INTO #tmp_DIM_Procedure

FROM	#tmp_DIM_Specimen				AS MS

	LEFT JOIN dbo.MicSpecimenProcedures AS DLT
		ON	MS.VisitID		= DLT.VisitID
		AND	MS.SpecimenID	= DLT.SpecimenID

	LEFT JOIN dbo.DMicProcs				AS DMP
		ON	DLT.ProcedureID	= DMP.ProcedureID



WHERE
	DLT.SourceID	=	'CEL'
--AND	DLT.Complete	=	'Y'
;


DROP TABLE IF EXISTS #tmp_DIM_Comment_Overall;

SELECT

	DLT.SpecimenID,
	DLT.ProcedureID,
	DLT.LinkProcedureID,
	CASE
		WHEN DLT.ProcedureID = '400.30500' 
			THEN 1
			ELSE 0
    END										AS IsOverall,
	CASE
		WHEN DLT.ProcedureID = '400.30070' 
			THEN 1
			ELSE 0
    END										AS IsComment,
	MSRT.TextLine							AS	ResultText
	
--INTO #tmp_DIM_Comment_Overall

FROM	#tmp_DIM_Specimen					AS MS

	LEFT JOIN dbo.MicSpecimenProcedures		AS DLT
		ON	MS.VisitID		= DLT.VisitID
		AND	MS.SpecimenID	= DLT.SpecimenID

	LEFT JOIN dbo.MicSpecimenResultsText	AS MSRT
		ON	DLT.SpecimenID	=	MSRT.SpecimenID 
		AND	DLT.ProcedureID	=	MSRT.ProcedureID

WHERE
	DLT.SourceID	=	'CEL'
--AND	DLT.Complete	=	'Y'
AND	MSRT.TextLine	IS NOT NULL
AND	MSRT.TextLine	<> ''
AND	MSRT.TextLine	<> 'See Details'
;



DROP TABLE IF EXISTS #tmp_DIM_Organisms;

SELECT 

	MS.SpecimenID,
	MSO.OrganismName

--INTO #tmp_DIM_Organisms

FROM 	#tmp_DIM_Specimen				AS MS

	LEFT JOIN dbo.MicSpecimenOrganisms	AS MSO
		ON	MS.VisitID		= MSO.VisitID
		AND	MS.SpecimenID	= MSO.SpecimenID

WHERE
	MSO.OrganismName	IS NOT NULL
;


/*
Abandoned Scripts:



USE livedb;

SELECT 

	RAM.AccountNumber,
	RAM.VisitID,
	RAM.PatientID,
	MS.Status,
	--RAM.RegistrationStatus	AS RAMREG,
	COALESCE(PV1.RegistrationStatus, PV2.RegistrationStatus)	AS PVREG,
	PAI.Name				AS PatientName,
	LOC.Name				AS UnitName,
	--DLT.ProcedureID,
	--DMP.Name				AS ProcedureName,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime
	
--INTO #tmp_micSpecMaster

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN livefocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID				=	RAM.VisitID

	LEFT JOIN DW_OSC.Patient.PatientVisit AS PV1
		ON	MS.VisitID				=	PV1.VisitID

	LEFT JOIN DW_OSC.Patient.PatientVisit AS PV2
		ON	MS.VisitID				=	PV2.ConvertedAcct_AcuteVisitID

	LEFT JOIN livefocdb.dbo.MisLoc_Main AS LOC
		ON	RAM.Location_MisLocID	=	LOC.MisLocID

	LEFT JOIN DW_OSC.Patient.PatientInfo AS PAI
		ON	RAM.PatientID			=	PAI.PatientID

	--LEFT JOIN dbo.MicSpecimenProcedures AS DLT
	--	ON	DLT.SourceID	=	'CEL'
	--	AND	MS.SpecimenID	=	DLT.SpecimenID

	--LEFT JOIN dbo.DMicProcs AS DMP
	--	ON	DLT.ProcedureID	= DMP.ProcedureID

WHERE

	RAM.Facility_MisFacID	IN ('WHA', 'OSCMHS')
AND	MS.Status				IN ('COMP', 'RES', 'UNV')				-- For completed orders only
--AND	DLT.Complete			= 'Y'						column
--AND PAI.Name	IS NULL

ORDER BY RAM.PatientID
--PAI.Name, MS.CollectionDateTime, MS.Status, MS.SpecimenID
;





SELECT

	RAM.AccountNumber,
	MS.SpecimenID,
	MSRT.TextLine,
	MSRT.ResultSeqID, 
	MSRT.TextSeqID, 
	MSRT.TextID,
	MS.CollectionDateTime


FROM	dbo.MicSpecimens AS MS

	LEFT JOIN dbo.MicSpecimenProcedures AS DLT
		ON	DLT.SourceID	=	'CEL'
		AND	MS.SpecimenID	=	DLT.SpecimenID

	LEFT JOIN livefocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID

	LEFT JOIN dbo.MicSpecimenResultsText AS MSRT
		ON	MS.SpecimenID	=	MSRT.SpecimenID 
		AND	DLT.ProcedureID	=	MSRT.ProcedureID

WHERE

	MSRT.SourceID	IS NOT NULL
AND	DLT.ProcedureID	in ('400.30070', '400.30500')						-- For only the comment & overall section
AND	RAM.Facility_MisFacID IN ('WHA', 'OSCMHS')
--AND MS.Status = 'COMP'													-- For completed orders only
;
*/