
SELECT
	
	RAM.AccountNumber,
	RAM.VisitID,
	RAM.PatientID,
	MSO.OrganismName,
	MSO.ResultSeqID,
	MS.SpecimenID,
	MS.CollectionDateTime,
	MS.ReceivedDateTime

FROM	dbo.MicSpecimens AS MS

	LEFT JOIN livefocdb.dbo.RegAcct_Main AS RAM
		ON	MS.VisitID		=	RAM.VisitID
				
	LEFT JOIN dbo.MicSpecimenOrganisms AS MSO
		ON	MS.SpecimenID	=	MSO.SpecimenID
		AND	RAM.VisitID		=	MSO.VisitID

WHERE

	RAM.Facility_MisFacID	IN ('WHA', 'OSHMHS')
AND	MS.CollectionDateTime	>= DATEADD(HOUR, -1, GETDATE())		-- NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
AND MS.Status				IN ('COMP')							-- For completed orders only
;